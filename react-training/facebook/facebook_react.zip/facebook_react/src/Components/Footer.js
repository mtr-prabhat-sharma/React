import React from 'react';
import '../style.css';

const Footer = () => {
  return (
    <footer className='footerClass'>
      <p>&copy;Copyright 2024</p>
    </footer>
  );
};

export default Footer;
