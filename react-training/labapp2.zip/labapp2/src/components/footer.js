
import './style.css' ;

export function Footer() {
    return(
        <h2 className='footerClass'>&copy;Copyright @ 2024</h2>
    )
}