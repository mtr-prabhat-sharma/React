import './style.css';

export function Aside() {
    return(
        <aside className="asideClass">
            <ul>
                <li>Home</li>
                <li>Product</li>
                <li>Careers</li>
                <li>Contact Us</li>
            </ul>
        </aside>
    )
}